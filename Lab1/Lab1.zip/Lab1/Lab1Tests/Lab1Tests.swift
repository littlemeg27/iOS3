//
//  Lab1Tests.swift
//  Lab1Tests
//
//  Created by Brenna Pavlinchak on 12/1/24.
//

import Testing
@testable import Lab1

struct Lab1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
