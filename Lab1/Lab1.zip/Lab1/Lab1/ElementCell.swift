//
//  ElementCell.swift
//  Lab1
//
//  Created by Brenna Pavlinchak on 12/1/24.
//

import UIKit

class ElementCell: UITableViewCell
{
    @IBOutlet weak var atomicLetterLabel: UILabel!
    @IBOutlet weak var atomicNameLabel: UILabel!

}
